<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Medicine;

class MedicineSeeder extends Seeder
{
    public function run(): void
    {
        for ($i = 1; $i <= 500; $i++) {
            Medicine::create([
                'name' => 'Medicine ' . $i,
                'strength' => rand(100, 1000) . 'mg',
                'form' => ['Tablet', 'Capsule', 'Syrup'][rand(0,2)],
                'category' => ['Antibiotic', 'Painkiller', 'Chronic'][rand(0,2)],
            ]);
        }
    }
}