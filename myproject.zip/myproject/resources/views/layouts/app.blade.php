<!DOCTYPE html>
<html>
<head>
    <title>Clinic Management System</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f4f6f9;
        }

        .sidebar {
            width: 220px;
            height: 100vh;
            position: fixed;
            background: #1e293b;
            color: white;
            padding: 20px;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            margin: 15px 0;
        }

        .sidebar a:hover {
            color: #38bdf8;
        }

        .main {
            margin-left: 240px;
            padding: 20px;
        }

        .card-custom {
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h3>🏥 Clinic System</h3>
    <a href="/dashboard">Dashboard</a>
    <a href="/inventory">Inventory</a>
    <a href="/inventory/create">Add Batch</a>
</div>

<!-- MAIN CONTENT -->
<div class="main">
    @yield('content')
</div>

</body>
</html>