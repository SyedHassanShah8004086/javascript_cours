@extends('layouts.app')

@section('content')

<h2>✏ Edit Batch</h2>

<form method="POST" action="/inventory/update/{{ $batch->id }}">
    @csrf

    <label>Medicine</label>
    <select name="medicine_id" class="form-control mb-2">
        @foreach($medicines as $medicine)
            <option value="{{ $medicine->id }}"
                {{ $batch->medicine_id == $medicine->id ? 'selected' : '' }}>
                {{ $medicine->name }}
            </option>
        @endforeach
    </select>

    <label>Batch Number</label>
    <input type="text" name="batch_number" value="{{ $batch->batch_number }}" class="form-control mb-2">

    <label>Quantity</label>
    <input type="number" name="quantity" value="{{ $batch->quantity }}" class="form-control mb-2">

    <label>Expiry Date</label>
    <input type="date" name="expiry_date" value="{{ $batch->expiry_date }}" class="form-control mb-2">

    <label>Location</label>
    <select name="location" class="form-control mb-2">
        <option value="Shelf A" {{ $batch->location === 'Shelf A' ? 'selected' : '' }}>Shelf A</option>
        <option value="Shelf B" {{ $batch->location === 'Shelf B' ? 'selected' : '' }}>Shelf B</option>
        <option value="Fridge" {{ $batch->location === 'Fridge' ? 'selected' : '' }}>Fridge</option>
        <option value="Cold Storage" {{ $batch->location === 'Cold Storage' ? 'selected' : '' }}>Cold Storage</option>
    </select>

    <button class="btn btn-success">Update</button>
</form>

@endsection