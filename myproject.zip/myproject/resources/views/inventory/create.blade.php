@extends('layouts.app')

@section('content')

<h2>Add Medicine Batch</h2>

<form method="POST" action="/inventory/store">
    @csrf
    
<select name="medicine_id" class="form-control" required>
    <option value="">Select Medicine</option>

    @foreach($medicines as $medicine)
        <option value="{{ $medicine->id }}">
            {{ $medicine->name }}
        </option>
    @endforeach

</select>

    <input type="text" name="batch_number" placeholder="Batch Number" class="form-control mb-2">

    <input type="number" name="quantity" placeholder="Quantity" class="form-control mb-2">

    <input type="date" name="expiry_date" class="form-control mb-2">

    <div class="mb-3">

    <label>Storage Location</label>

    <select name="location" class="form-control">

        <option value="Shelf A">Shelf A</option>
        <option value="Shelf B">Shelf B</option>
        <option value="Fridge">Fridge</option>
        <option value="Cold Storage">Cold Storage</option>

    </select>

</div>

    <button class="btn btn-success">Save</button>
</form>

@endsection