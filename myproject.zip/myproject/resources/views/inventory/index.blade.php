@extends('layouts.app')

@section('content')

<h2 class="mb-3">📦 Inventory Management</h2>

<!-- SEARCH + FILTER -->
<div class="row mb-3">

    <!-- SEARCH -->
    <div class="col-12 col-md-6 mb-2">
        <input type="text" id="search" class="form-control" placeholder="Search medicine...">
    </div>

    <!-- CATEGORY FILTER -->
    <div class="col-12 col-md-6">
        <select id="categoryFilter" class="form-control">

            <option value="">All Categories</option>
            <option value="Antibiotic">Antibiotic</option>
            <option value="Painkiller">Painkiller</option>
            <option value="Chronic">Chronic</option>
            <option value="Cough">Cough</option>

        </select>
    </div>

</div>

<!-- SUCCESS MESSAGE -->
@if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

<!-- TABLE -->
<div class="table-responsive shadow-sm">

<table class="table table-hover align-middle" id="inventoryTable">

    <thead class="table-dark">
        <tr>
            <th>Medicine</th>
            <th>Batch</th>
            <th>Qty</th>
            <th>Expiry</th>
            <th>Status</th>
            <th>Action</th>
            <th>QR Code</th>
        </tr>
    </thead>

    <tbody>

    @forelse($batches as $batch)

        @php
            $daysLeft = \Carbon\Carbon::now()
                ->diffInDays(\Carbon\Carbon::parse($batch->expiry_date), false);
        @endphp

        <tr 
            data-category="{{ $batch->medicine->category ?? '' }}"

            @if($batch->quantity <= 5)
                style="background-color:#ffe6e6;"
            @elseif($daysLeft <= 10)
                style="background-color:#fff3cd;"
            @endif
        >

            <td>{{ $batch->medicine->name ?? 'N/A' }}</td>
            <td>{{ $batch->batch_number }}</td>
            <td>{{ $batch->quantity }}</td>
            <td>{{ $batch->expiry_date }}</td>

            <td>
                @if($batch->quantity <= 5)
                    <span class="badge bg-danger">🔴 Low Stock</span>

                @elseif($daysLeft < 0)
                    <span class="badge bg-dark">⚫ Expired</span>

                @elseif($daysLeft <= 10)
                    <span class="badge bg-danger">🔴 Critical</span>

                @elseif($daysLeft <= 30)
                    <span class="badge bg-warning text-dark">🟡 Warning</span>

                @else
                    <span class="badge bg-success">🟢 Stable</span>
                @endif
            </td>

            <!-- ACTION -->
            <td>
                <div class="d-flex gap-1 flex-wrap">

                    <a href="/inventory/edit/{{ $batch->id }}" class="btn btn-sm btn-warning">
                        ✏ Edit
                    </a>

                    <form action="/inventory/delete/{{ $batch->id }}" method="POST">
                        @csrf
                        @method('DELETE')

                        <button type="submit"
                            class="btn btn-sm btn-danger"
                            onclick="return confirm('Are you sure?')">
                            🗑 Delete
                        </button>
                    </form>

                </div>
            </td>

            <!-- QR -->
            <td class="text-center">
                <div style="max-width:90px; margin:auto;">
                    {!! QrCode::size(80)->generate(
                        "Medicine: ".$batch->medicine->name.
                        " | Batch: ".$batch->batch_number.
                        " | Qty: ".$batch->quantity.
                        " | Exp: ".$batch->expiry_date.
                        " | Location: ".$batch->location
                    ) !!}
                </div>
            </td>

        </tr>

    @empty

        <tr>
            <td colspan="7" class="text-center text-muted py-4">
                No inventory data available
            </td>
        </tr>

    @endforelse

    </tbody>

</table>

</div>

<!-- ADD BUTTON -->
<a href="/inventory/create" class="btn btn-primary mt-3">
    ➕ Add New Batch
</a>

<!-- 🔥 ADVANCED FILTER SCRIPT -->
<script>

const searchInput = document.getElementById('search');
const categoryFilter = document.getElementById('categoryFilter');
const rows = document.querySelectorAll("#inventoryTable tbody tr");

function filterTable() {

    let searchValue = searchInput.value.toLowerCase();
    let categoryValue = categoryFilter.value.toLowerCase();

    rows.forEach(row => {

        let text = row.innerText.toLowerCase();
        let category = (row.getAttribute('data-category') || '').toLowerCase();

        let matchSearch = text.includes(searchValue);
        let matchCategory = categoryValue === "" || category.includes(categoryValue);

        if (matchSearch && matchCategory) {
            row.style.display = "";
        } else {
            row.style.display = "none";
        }

    });

}

searchInput.addEventListener('keyup', filterTable);
categoryFilter.addEventListener('change', filterTable);

</script>

@endsection