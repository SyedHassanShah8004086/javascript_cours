@extends('layouts.app')

@section('content')

<h2>📊 Inventory Dashboard</h2>

<div class="row mt-4">

    <div class="col-md-3">
        <div class="card text-white bg-primary p-3">
            <h5>Total Batches</h5>
            <h2>{{ $totalBatches }}</h2>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card text-white bg-danger p-3">
            <h5>Low Stock</h5>
            <h2>{{ $lowStock }}</h2>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card text-white bg-warning p-3">
            <h5>Expiring Soon</h5>
            <h2>{{ $expiringSoon }}</h2>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card text-white bg-success p-3">
            <h5>Total Stock</h5>
            <h2>{{ $totalStock }}</h2>
        </div>
    </div>

</div>

@endsection