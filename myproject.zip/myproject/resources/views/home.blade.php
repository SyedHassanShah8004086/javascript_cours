<!DOCTYPE html>
<html>
<head>
    <title>My Home Page</title>
</head>
<body>
    <h1>Welcome Shah Saab 👋</h1>
    <p>Your Laravel project is working!</p>
</body>
</html>