

<?php $__env->startSection('content'); ?>

<h2 class="mb-3">📦 Inventory Management</h2>

<!-- SEARCH + FILTER -->
<div class="row mb-3">

    <!-- SEARCH -->
    <div class="col-12 col-md-6 mb-2">
        <input type="text" id="search" class="form-control" placeholder="Search medicine...">
    </div>

    <!-- CATEGORY FILTER -->
    <div class="col-12 col-md-6">
        <select id="categoryFilter" class="form-control">

            <option value="">All Categories</option>
            <option value="Antibiotic">Antibiotic</option>
            <option value="Painkiller">Painkiller</option>
            <option value="Chronic">Chronic</option>
            <option value="Cough">Cough</option>

        </select>
    </div>

</div>

<!-- SUCCESS MESSAGE -->
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<!-- TABLE -->
<div class="table-responsive shadow-sm">

<table class="table table-hover align-middle" id="inventoryTable">

    <thead class="table-dark">
        <tr>
            <th>Medicine</th>
            <th>Batch</th>
            <th>Qty</th>
            <th>Expiry</th>
            <th>Status</th>
            <th>Action</th>
            <th>QR Code</th>
        </tr>
    </thead>

    <tbody>

    <?php $__empty_1 = true; $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <?php
            $daysLeft = \Carbon\Carbon::now()
                ->diffInDays(\Carbon\Carbon::parse($batch->expiry_date), false);
        ?>

        <tr 
            data-category="<?php echo e($batch->medicine->category ?? ''); ?>"

            <?php if($batch->quantity <= 5): ?>
                style="background-color:#ffe6e6;"
            <?php elseif($daysLeft <= 10): ?>
                style="background-color:#fff3cd;"
            <?php endif; ?>
        >

            <td><?php echo e($batch->medicine->name ?? 'N/A'); ?></td>
            <td><?php echo e($batch->batch_number); ?></td>
            <td><?php echo e($batch->quantity); ?></td>
            <td><?php echo e($batch->expiry_date); ?></td>

            <td>
                <?php if($batch->quantity <= 5): ?>
                    <span class="badge bg-danger">🔴 Low Stock</span>

                <?php elseif($daysLeft < 0): ?>
                    <span class="badge bg-dark">⚫ Expired</span>

                <?php elseif($daysLeft <= 10): ?>
                    <span class="badge bg-danger">🔴 Critical</span>

                <?php elseif($daysLeft <= 30): ?>
                    <span class="badge bg-warning text-dark">🟡 Warning</span>

                <?php else: ?>
                    <span class="badge bg-success">🟢 Stable</span>
                <?php endif; ?>
            </td>

            <!-- ACTION -->
            <td>
                <div class="d-flex gap-1 flex-wrap">

                    <a href="/inventory/edit/<?php echo e($batch->id); ?>" class="btn btn-sm btn-warning">
                        ✏ Edit
                    </a>

                    <form action="/inventory/delete/<?php echo e($batch->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit"
                            class="btn btn-sm btn-danger"
                            onclick="return confirm('Are you sure?')">
                            🗑 Delete
                        </button>
                    </form>

                </div>
            </td>

            <!-- QR -->
            <td class="text-center">
                <div style="max-width:90px; margin:auto;">
                    <?php echo QrCode::size(80)->generate(
                        "Medicine: ".$batch->medicine->name.
                        " | Batch: ".$batch->batch_number.
                        " | Qty: ".$batch->quantity.
                        " | Exp: ".$batch->expiry_date.
                        " | Location: ".$batch->location
                    ); ?>

                </div>
            </td>

        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <tr>
            <td colspan="7" class="text-center text-muted py-4">
                No inventory data available
            </td>
        </tr>

    <?php endif; ?>

    </tbody>

</table>

</div>

<!-- ADD BUTTON -->
<a href="/inventory/create" class="btn btn-primary mt-3">
    ➕ Add New Batch
</a>

<!-- 🔥 ADVANCED FILTER SCRIPT -->
<script>

const searchInput = document.getElementById('search');
const categoryFilter = document.getElementById('categoryFilter');
const rows = document.querySelectorAll("#inventoryTable tbody tr");

function filterTable() {

    let searchValue = searchInput.value.toLowerCase();
    let categoryValue = categoryFilter.value.toLowerCase();

    rows.forEach(row => {

        let text = row.innerText.toLowerCase();
        let category = (row.getAttribute('data-category') || '').toLowerCase();

        let matchSearch = text.includes(searchValue);
        let matchCategory = categoryValue === "" || category.includes(categoryValue);

        if (matchSearch && matchCategory) {
            row.style.display = "";
        } else {
            row.style.display = "none";
        }

    });

}

searchInput.addEventListener('keyup', filterTable);
categoryFilter.addEventListener('change', filterTable);

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\myproject\resources\views/inventory/index.blade.php ENDPATH**/ ?>