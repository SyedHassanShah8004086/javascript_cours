

<?php $__env->startSection('content'); ?>

<h2>✏ Edit Batch</h2>

<form method="POST" action="/inventory/update/<?php echo e($batch->id); ?>">
    <?php echo csrf_field(); ?>

    <label>Medicine</label>
    <select name="medicine_id" class="form-control mb-2">
        <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($medicine->id); ?>"
                <?php echo e($batch->medicine_id == $medicine->id ? 'selected' : ''); ?>>
                <?php echo e($medicine->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label>Batch Number</label>
    <input type="text" name="batch_number" value="<?php echo e($batch->batch_number); ?>" class="form-control mb-2">

    <label>Quantity</label>
    <input type="number" name="quantity" value="<?php echo e($batch->quantity); ?>" class="form-control mb-2">

    <label>Expiry Date</label>
    <input type="date" name="expiry_date" value="<?php echo e($batch->expiry_date); ?>" class="form-control mb-2">

    <label>Location</label>
    <select name="location" class="form-control mb-2">
        <option value="Shelf A" <?php echo e($batch->location === 'Shelf A' ? 'selected' : ''); ?>>Shelf A</option>
        <option value="Shelf B" <?php echo e($batch->location === 'Shelf B' ? 'selected' : ''); ?>>Shelf B</option>
        <option value="Fridge" <?php echo e($batch->location === 'Fridge' ? 'selected' : ''); ?>>Fridge</option>
        <option value="Cold Storage" <?php echo e($batch->location === 'Cold Storage' ? 'selected' : ''); ?>>Cold Storage</option>
    </select>

    <button class="btn btn-success">Update</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\myproject\resources\views/inventory/edit.blade.php ENDPATH**/ ?>