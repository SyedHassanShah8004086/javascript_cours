

<?php $__env->startSection('content'); ?>

<h2>Add Medicine Batch</h2>

<form method="POST" action="/inventory/store">
    <?php echo csrf_field(); ?>
    
<select name="medicine_id" class="form-control" required>
    <option value="">Select Medicine</option>

    <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($medicine->id); ?>">
            <?php echo e($medicine->name); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</select>

    <input type="text" name="batch_number" placeholder="Batch Number" class="form-control mb-2">

    <input type="number" name="quantity" placeholder="Quantity" class="form-control mb-2">

    <input type="date" name="expiry_date" class="form-control mb-2">

    <div class="mb-3">

    <label>Storage Location</label>

    <select name="location" class="form-control">

        <option value="Shelf A">Shelf A</option>
        <option value="Shelf B">Shelf B</option>
        <option value="Fridge">Fridge</option>
        <option value="Cold Storage">Cold Storage</option>

    </select>

</div>

    <button class="btn btn-success">Save</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\myproject\resources\views/inventory/create.blade.php ENDPATH**/ ?>