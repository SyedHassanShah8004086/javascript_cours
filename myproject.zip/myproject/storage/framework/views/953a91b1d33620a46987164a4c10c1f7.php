

<?php $__env->startSection('content'); ?>

<h2>📊 Inventory Dashboard</h2>

<div class="row mt-4">

    <div class="col-md-3">
        <div class="card text-white bg-primary p-3">
            <h5>Total Batches</h5>
            <h2><?php echo e($totalBatches); ?></h2>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card text-white bg-danger p-3">
            <h5>Low Stock</h5>
            <h2><?php echo e($lowStock); ?></h2>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card text-white bg-warning p-3">
            <h5>Expiring Soon</h5>
            <h2><?php echo e($expiringSoon); ?></h2>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card text-white bg-success p-3">
            <h5>Total Stock</h5>
            <h2><?php echo e($totalStock); ?></h2>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hp\Desktop\myproject\resources\views/dashboard.blade.php ENDPATH**/ ?>