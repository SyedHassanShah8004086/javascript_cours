<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\InventoryController;

Route::get('/', function () {
    return redirect('/dashboard');
});

Route::get('/dashboard', [InventoryController::class, 'dashboard']);

Route::get('/inventory', [InventoryController::class, 'index']);

Route::get('/inventory/create', [InventoryController::class, 'create']);

Route::post('/inventory/store', [InventoryController::class, 'store']);
Route::get('/inventory/edit/{id}', [InventoryController::class, 'edit']);
Route::post('/inventory/update/{id}', [InventoryController::class, 'update']);
Route::delete('/inventory/delete/{id}', [InventoryController::class, 'delete']);