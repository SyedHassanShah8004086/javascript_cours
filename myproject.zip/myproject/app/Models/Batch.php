<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Medicine; // ✅ IMPORTANT ADD THIS

class Batch extends Model
{
    use HasFactory;

    protected $fillable = [
        'medicine_id',
        'batch_number',
        'quantity',
        'expiry_date',
        'location'
    ];

    public function medicine()
    {
        return $this->belongsTo(Medicine::class);
    }
}