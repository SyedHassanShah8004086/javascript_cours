<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Batch; // 🔥 IMPORTANT ADD THIS

class Medicine extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'strength',
        'form',
        'category'
    ];

    public function batches()
    {
        return $this->hasMany(Batch::class);
    }
}