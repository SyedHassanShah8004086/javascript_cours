<?php

namespace App\Http\Controllers;

use App\Models\Batch;
use App\Models\Medicine;   // ✅ ONLY HERE
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Activity;
use SimpleSoftwareIO\QrCode\Facades\QrCode;


class InventoryController extends Controller
{
    public function dashboard()
    {
        $totalBatches = Batch::count();
        $lowStock = Batch::where('quantity', '<=', 5)->count();
        $expiringSoon = Batch::whereDate('expiry_date', '<=', Carbon::now()->addDays(30))->count();
        $totalStock = Batch::sum('quantity');

        return view('dashboard', compact(
            'totalBatches',
            'lowStock',
            'expiringSoon',
            'totalStock'
        ));
    }

public function index(Request $request)
{
    $query = Batch::with('medicine');

    // CATEGORY FILTER FIX
    if ($request->category) {
        $query->whereHas('medicine', function ($q) use ($request) {
            $q->where('category', $request->category);
        });
    }

    $batches = $query->orderBy('expiry_date', 'asc')->get();

    return view('inventory.index', compact('batches'));
}

    public function create()
    {
        $medicines = Medicine::all();
        return view('inventory.create', compact('medicines'));
    }

   public function store(Request $request)
{
    $request->validate([
        'medicine_id' => 'required|exists:medicines,id',
        'batch_number' => 'required',
        'quantity' => 'required|numeric',
        'expiry_date' => 'required',
        'location' => 'required',
    ]);

    $batch = Batch::create($request->all());

    // ✅ Activity Log
    Activity::create([
        'action' => 'ADD',
        'description' => 'Added batch ' . $batch->batch_number
    ]);

    return redirect('/inventory')->with('success', 'Batch added successfully');
}

    public function edit($id)
    {
        $batch = Batch::findOrFail($id);
        $medicines = Medicine::all();

        return view('inventory.edit', compact('batch', 'medicines'));
    }

  public function update(Request $request, $id)
{
    $request->validate([
        'medicine_id' => 'required|exists:medicines,id',
        'batch_number' => 'required',
        'quantity' => 'required|numeric',
        'expiry_date' => 'required',
        'location' => 'required',
    ]);

    $batch = Batch::findOrFail($id);

    $batch->update([
        'medicine_id' => $request->medicine_id,
        'batch_number' => $request->batch_number,
        'quantity' => $request->quantity,
        'expiry_date' => $request->expiry_date,
        'location' => $request->location,
    ]);

    // ✅ Activity Log
    Activity::create([
        'action' => 'UPDATE',
        'description' => 'Updated batch ' . $batch->batch_number
    ]);

    return redirect('/inventory')->with('success', 'Batch updated successfully');
}
public function delete($id)
{
    $batch = Batch::findOrFail($id);

    // ✅ Activity Log BEFORE delete
    Activity::create([
        'action' => 'DELETE',
        'description' => 'Deleted batch ' . $batch->batch_number
    ]);

    $batch->delete();

    return redirect('/inventory')->with('success', 'Batch deleted successfully');
}
}